
public class Iteration extends Result{

	Result iterat;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[ + " + iterat+"]";
	}
}
