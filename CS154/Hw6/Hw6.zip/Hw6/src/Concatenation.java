public class Concatenation extends Result{
	
	Result one;
	Result two;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[" +one +" ~ "+two+ "]";
	}
	
}
