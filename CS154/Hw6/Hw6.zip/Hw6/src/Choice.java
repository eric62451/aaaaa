
public class Choice extends Result{
	
	Result choice;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[ | " + choice+"]";
	}
}
