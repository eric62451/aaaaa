
public class Option extends Result{
	
	Result opt;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[ ? " + opt+"]";
	}
}
