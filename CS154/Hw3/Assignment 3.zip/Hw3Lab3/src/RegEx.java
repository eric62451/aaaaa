/*
 * Eric Tam
 * 007989423
 * CS154
 * Assignment 3
 */

public interface RegEx {

	public boolean matches(String s);
}
