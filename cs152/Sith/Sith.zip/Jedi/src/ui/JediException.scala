/*
Eric Tam
007989423
CS-152
*/
package ui

class JediException(val msg: String = "Your force is weak") extends Exception(msg){

}