/*
Eric Tam
007989423
CS-152
*/
package ui
import values._


object testDriver {
	def main(args: Array[String]): Unit = {
	  Number.test
	  Boole.test
	  Environment.test
	  system.test
	}
}