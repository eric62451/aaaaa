/*
Eric Tam
007989423
CS-152
*/
package expressions

trait SpecialForm extends Expression{

}