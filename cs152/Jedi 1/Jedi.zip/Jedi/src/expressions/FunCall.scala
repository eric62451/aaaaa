/*
Eric Tam
007989423
CS-152
*/
package expressions
import values._
case class FunCall(cmd : String) extends Expression{
def execute( env : Environment):Value = ???
}