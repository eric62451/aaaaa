/*
Eric Tam
007989423
CS-152
*/
package expressions
import values._

case class Literal() extends Expression with Value {
  def execute(env: Environment): Value = ???
}