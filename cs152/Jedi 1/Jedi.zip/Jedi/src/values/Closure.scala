/*
Eric Tam
007989423
CS-152
*/
package values

class Closure(val defEnv: Environment) extends Value{

}