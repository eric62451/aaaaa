/*
Eric Tam
007989423
CS-152
*/
package ui

import values._
import expressions._

object codeChecker {
  def main(args: Array[String]): Unit = { check(); }
  
  def check() {
    println("Checking Number class:")
    val num1 = new Number(100.0)
    val num2 = new Number(42.0)
    println("...expected = " + (100.0 + 42.0) + ", actual = " + (num1 + num2))
    println("...expected = " + (100.0 * 42.0) + ", actual = " + (num1 * num2))
    println("...expected = " + (100.0 - 42.0) + ", actual = " + (num1 - num2))
    println("...expected = " + (100.0 / 42.0) + ", actual = " + (num1 / num2))
    println("...expected = " + (100.0 < 42.0) + ", actual = " + (num1 < num2))
    println("...expected = " + (100.0 == 42.0) + ", actual = " + (num1 == num2))
    
    println("Checking Boole class:")
    val t = new Boole(true)
    val f = new Boole(false)
    println("...expected = " + (true && false) + ", actual = " + (t && f))
    println("...expected = " + (true && true) + ", actual = " + (t && t))
    println("...expected = " + (true || false) + ", actual = " + (t || f))
    println("...expected = " + (false || false) + ", actual = " + (f && f))
    
    println("Checking Environment class:")
    val n1 = new Identifier("n1")
    val n2 = new Identifier("n2")
    val n3 = new Identifier("n3")
    val n4 = new Identifier("n4")
    val b1 = new Identifier("b1")
    val b2 = new Identifier("b2")
    val b3 = new Identifier("b3")
    val b4 = new Identifier("b4")
    val x = new Identifier("x")
    val globalEnv = new Environment()
    val env1 = new Environment(globalEnv)
    val env2 = new Environment(env1)
    globalEnv.put(List(n1, n2, b1, b2), List(num1, num2, t, f))
    env1.put(List(n3, b3), List(num1 + num2, num1 < num2)) 
    env2.put(List(n2, n4, b3, b4), List(num2 - num1, num1 / num2, num2 < num1, f))
    
    println("...expected = " + num1 + " actual = " + env2.find(n1))
    println("...expected = " + (num2 - num1) + " actual = " + env2.find(n2))
    println("...expected = " + (num2 + num1) + " actual = " + env2.find(n3))
    println("...expected = " + (num1 / num2) + " actual = " + env2.find(n4))
    println("...expected = " + (t) + " actual = " + env2.find(b1))
    println("...expected = " + (f) + " actual = " + env2.find(b2))
    println("...expected = " + (num2 < num1) + " actual = " + env2.find(b3))
    println("...expected = " + (f) + " actual = " + env2.find(b4))
    println("...expected = " + Notification.UNKNOWN + " actual = " + env2.find(x))
    
    println("Checking polymorphism:")
    var exp: Expression = num1
    println("...exp = " + exp)
    exp = t
    println("...exp = " + exp)
    exp = n1
    println("...exp = " + exp)
    var value: Value = num1
    println("...value = " + value)
    value = t
    println("...value = " + value)
    value = env2
    println("...value = " + value)    
  }

  

}