/*
Eric Tam
007989423
CS-152
*/
package ui

class TypeException extends JediException{

}