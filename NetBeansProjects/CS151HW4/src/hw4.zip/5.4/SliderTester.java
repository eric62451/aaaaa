import javax.swing.JFrame;
/**
 * Eric Tam
 * CS151 - Section 1
 * Homework 4
 * 5.4
 */
public class SliderTester {
	public static void main(String[] args) {
                Slider slide = new Slider();

	}
}
