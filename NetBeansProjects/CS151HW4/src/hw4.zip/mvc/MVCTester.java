/**
 * Eric Tam
 * CS151 - Section 1
 * Homework 4
 * MVC
 */

public class MVCTester {
	public static void main(String[] args) {
		Model data = new Model();
                Controller control = new Controller(data);
		

	}
}
