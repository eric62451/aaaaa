package com.factorynoir.bukkitPlugin;

import java.util.Arrays;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.CommandSender;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.Material;
import org.bukkit.World.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

public class main extends JavaPlugin {

    private final String HELLO_MESSAGE = "Hello world... (this is the example bukkit plugin.)";
    private final String GOODBYE_MESSAGE = "Goodbye world... (this is the example bukkit plugin.)";
    private Location worldspawn, netherspawn;
    private final String folder = "./plugins/Teleporter/";

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        getLogger().info("plugin commad used");

        if (cmd.getName().equalsIgnoreCase("foo")) {
            Player player = (Player) sender;
            getLogger().info("Im ThaMaster of coding");
            if (args.length == 0) {
                args = new String[]{"0"};
            }
            sender.sendMessage(player.getWorld().getName());
            player.teleport(new Location(Bukkit.getWorld("world"), 100, 100, 100));
            return true;
        } /*else if (cmd.getName().equalsIgnoreCase("getthetime")) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        sender.sendMessage("The time is now " + dateFormat.format(date));
        } else*/

        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (cmd.getLabel().equalsIgnoreCase("sethome")) {
                if (args.length == 0) {
                    sender.sendMessage("Please enter a name for the location Ex: /sethome <LocationName>");
                } else {
                    Location loc = player.getLocation();
                    String content = "";
                    String path = folder + player.getName() + ".txt";
                    String data = args[0] + " '" + loc.getWorld().getName() + "' " + loc.getX() + " " + loc.getY() + " " + loc.getZ();
                    try {
                        rm(args[0], path);
                        content = new Scanner(new File(path)).useDelimiter("\\Z").next();
                        content = content + "\r\n" + data;

                    } catch (Exception e) {
                        //data = data;
                        content = data;
                    } finally {
                        try {
                            PrintWriter out = new PrintWriter(path);
                            out.print(content);
                            out.close();
                        } catch (FileNotFoundException e) {
                        }
                        sender.sendMessage("Location " + args[0] + " set");
                    }
                }
            } else if (cmd.getLabel().equalsIgnoreCase("rmhome")) {
                if (args.length == 0) {
                    args = new String[]{"world"};
                }
                String path = folder + player.getName() + ".txt";
                try {
                    rm(args[0], path);
                } catch (FileNotFoundException ex) {
                }
                sender.sendMessage("home " + args[0] + " removed");
            } else if (cmd.getLabel().equalsIgnoreCase("tp")) {
                if (args.length == 0) {
                    sender.sendMessage("Please enter a location name you wish to teleport Ex: /tp <LocationName>");
                } else {
                    String path = folder + player.getName() + ".txt";
                    try {
                        Scanner reader = new Scanner(new File(path));
                        String line = args[0] + " ";
                        String readLine = null;
                        while ((readLine = reader.nextLine()) != null && !readLine.contains(line)) {
                        }

                        String[] split = readLine.split(" ");
                        String worldType = split[1].replace("'", "");
                        double xCoord = Double.parseDouble(split[2]);
                        double yCoord = Double.parseDouble(split[3]);
                        double zCoord = Double.parseDouble(split[4]);

                        player.teleport(new Location((Bukkit.getWorld(worldType)), xCoord, yCoord, zCoord));

                    } catch (Exception e) {
                        sender.sendMessage("Location " + args[0] + " unknown");
                    }

                }

            }
        }
        return true;
    }

    /* onEnable and onDisable get invoked when the server is started up, shut down, restarted...
     * In the console try doing a /reload
     */
    @Override
    public void onEnable() {
        getLogger().info(HELLO_MESSAGE);
        File direct = new File("plugins/Teleporter");
        direct.mkdir();
        try {
            Scanner in = new Scanner(new File(folder + "settings.set"));
            in.next();
            worldspawn = new Location(Bukkit.getWorld("world"), in.nextDouble(), in.nextDouble(), in.nextDouble());
            in.next();
            netherspawn = new Location(Bukkit.getWorld("world_nether"), in.nextDouble(), in.nextDouble(), in.nextDouble());
        } catch (FileNotFoundException e) {
            try {
                PrintWriter out = new PrintWriter(folder + "settings.set");
                String content = "world 0 0 0 nether 0 0 0";
                out.print(content);
                out.close();
            } catch (FileNotFoundException a) {
            }
        }
    }

    @Override
    public void onDisable() {
        getLogger().info(GOODBYE_MESSAGE);
    }

    public void logToFile(String message) {
        try {
            File dataFolder = getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdir();
            }

            File saveTo = new File(getDataFolder(), "myplugin.log");
            if (!saveTo.exists()) {
                saveTo.createNewFile();
            }

            FileWriter fw = new FileWriter(saveTo, true);

            PrintWriter pw = new PrintWriter(fw);

            pw.println(message);
            pw.flush();
            pw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void rm(String remove, String path) throws FileNotFoundException {
        try {
            String content = new Scanner(new File(path)).useDelimiter("\\Z").next();
            int index = content.indexOf(remove + " ");
            if (index != -1) {
                int ind = content.indexOf("\r\n", index);
                if (ind != -1) {
                    content = content.substring(0, index) + content.substring(ind + 2);
                } else {
                    content = content.substring(0, index);
                }
            }
            //content = "world normal 1 2 3\ncavee nether 3 2 1\nhi normal 1 2 3\n";
            PrintWriter out = new PrintWriter(path);
            out.print(content);
            out.close();
        } catch (NoSuchElementException e) {
        }

    }
}
