CREATE DATABASE racqual;
use racqual;