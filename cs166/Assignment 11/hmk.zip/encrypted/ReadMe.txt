Files ending with .class.enc are encrypted class files

To run the application:
java sandmark/obfuscate/encryptclasses/EncryptedClassLoader

This will the encrypted application.

Your challenge is to generate plaintext versions of the encrypted class files (from which source .java files can easily be generated).